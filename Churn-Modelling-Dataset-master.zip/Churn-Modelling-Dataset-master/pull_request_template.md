# please take some beginner tutorial before getting started with Colabs
# ignore mounting drive onto colab if ot using it.
